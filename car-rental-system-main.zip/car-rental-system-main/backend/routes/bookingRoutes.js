import express from "express";
import { checkCarAvailabilityOfCar, createBooking, getUserBookings, getOwnerBookings, ChangeBookingStatus} from "../controllers/bookingController.js";
import { protect } from "../middleware/auth.js";

const bookingRouter = express.Router();

bookingRouter.post("/check-availability",checkCarAvailabilityOfCar)
bookingRouter.post("/create",protect,createBooking)
bookingRouter.get("/user",protect,getUserBookings)
bookingRouter.get("/owner",protect,getOwnerBookings)
bookingRouter.post("/change-status",protect,ChangeBookingStatus)

export default bookingRouter;