import React from 'react';

const Title = ({ title, subtitle }) => {
    return (
        <>
            <h2 className="text-3xl font-medium">
                {title}
            </h2>

            <p className="text-gray-500/90 text-sm md:text-base mt-2 max-w-156">
                {subtitle}
            </p>
        </>
    );
};

export default Title;
